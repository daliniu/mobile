//
//  WirelessUnifiedProtocolTests.h
//  WirelessUnifiedProtocolTests
//
//  Created by 壬俊 易 on 12-3-29.
//  Copyright (c) 2012年 Tencent. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface WirelessUnifiedProtocolTests : SenTestCase

@end
