//
//  WirelessUnifiedProtocolTests.m
//  WirelessUnifiedProtocolTests
//
//  Created by 壬俊 易 on 12-3-29.
//  Copyright (c) 2012年 Tencent. All rights reserved.
//

#import "WirelessUnifiedProtocolTests.h"

@implementation WirelessUnifiedProtocolTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in WirelessUnifiedProtocolTests");
}

@end
