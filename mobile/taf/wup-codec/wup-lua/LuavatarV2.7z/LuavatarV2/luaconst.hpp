#ifndef _LUA_CONST_HPP_
#define _LUA_CONST_HPP_

#include "luavalue.h"

namespace Luavatar
{
}

#endif
