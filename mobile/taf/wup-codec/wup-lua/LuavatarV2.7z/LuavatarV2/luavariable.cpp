#include <cassert>
#include "luastate.h"
#include "luautil.h"
#include <iostream>

namespace Luavatar
{
   // - LuaVariable::LuaVariable -----------------------------------------------
   LuaVariable::LuaVariable (lua_State* state, const LuaValue& key,
                             const KeyList& predKeys)
      : state_(state), keys_(predKeys)
   {
      keys_.push_back (key);
      value_.eType = dataNil;
   }


   void LuaVariable::emptyTable()
   {
        pushLastTable();
        LuaUtil::PushLuaValue (state_, keys_.back());
        lua_newtable(state_);

        lua_settable (state_, -3);
        lua_pop (state_, 1);

        return;
   }

   // - LuaVariable::operator= -------------------------------------------------
   /**
    * ��ֵ����������LuaValue��Ϊ��������������ΪLuaValue�Ĺ��캯�����������Ͷ�����
    * ����ʽת��ΪLuaValue��ͬʱ��
    */
   const LuaValue& LuaVariable::operator= (const LuaValue& rhs)
   {
      pushLastTable();
      LuaUtil::PushLuaValue (state_, keys_.back());
      LuaUtil::PushLuaValue (state_, rhs);
      
      lua_settable (state_, -3);
      lua_pop (state_, 1);

      return rhs;
   }

   // - LuaVariable::value -----------------------------------------------------
   // ע��:�����ֻ����table��ĳһЩ�򣬱㲻Ҫ������table value������ֻvalue��Ҫ���ʵ���
   //      �������Է�ֹ����Ҫ�ĳ�ջ�����Ч�ʡ�
   const LuaValue& LuaVariable::value()
   {
      pushTheReferencedValue();
      LuaUtil::ToLuaValue (state_, -1, value_);
      lua_pop (state_, 1);
      return value_;
   }

   // - LuaVariable::operator[] ------------------------------------------------
   // table tricker
   LuaVariable LuaVariable::operator[] (const LuaValue& key)
   {
      return LuaVariable (state_, key, keys_);
   }

   //function tricker
   int LuaVariable::operator()() const
   {
        pushTheReferencedValue();
        return LuaUtil::CallFunctionOnTop (state_, NullList, NullList);
   }

   int LuaVariable::operator()(const LuaValueList& params) const
   {
        pushTheReferencedValue();
        return LuaUtil::CallFunctionOnTop (state_, params, NullList);
   }

   int LuaVariable::operator()(LuaValueList& values) const
   {
        pushTheReferencedValue();
        return LuaUtil::CallFunctionOnTop (state_, NullList, values);
   }
   
   int LuaVariable::operator()(const LuaValueList& params,LuaValueList& values) const
   {
        pushTheReferencedValue();
        return LuaUtil::CallFunctionOnTop (state_, params, values);
   }

   // - LuaVariable::pushLastTable ---------------------------------------------
   void LuaVariable::pushLastTable()
   {
      lua_pushstring (state_, "_G");
      lua_gettable (state_, LUA_GLOBALSINDEX);

      typedef KeyList::const_iterator iter_t;

      assert (keys_.size() > 0 && "At least one key should be present here.");

      iter_t end = keys_.end();
      --end;

      for (iter_t p = keys_.begin(); p != end; ++p)
      {
         LuaUtil::PushLuaValue (state_, *p);
         lua_gettable (state_, -2);
         if (!lua_istable (state_, -1))
         {
            throw TypeMismatchError ("table", luaL_typename (state_, -1));
         }
         lua_remove (state_, -2);
      }
   }

   // - LuaVariable::pushTheReferencedValue ------------------------------------
   void LuaVariable::pushTheReferencedValue() const
   {
      assert (keys_.size() > 0 && "There should be at least one key here.");

      int index = LUA_GLOBALSINDEX;

      typedef std::vector<LuaValue>::const_iterator iter_t;
      for (iter_t p = keys_.begin(); p != keys_.end(); ++p)
      {
         LuaUtil::PushLuaValue (state_, *p);
         lua_gettable (state_, index);

         if (keys_.size() > 1 && p != keys_.end()-1 && !lua_istable(state_, -1))
         {
            throw TypeMismatchError ("table", p->typeName());
         }

         if (index != LUA_GLOBALSINDEX)
         {
            lua_remove (state_, -2);
         }
         else
         {
            index = -2;
         }
      }
   }

} // namespace Luavatar


