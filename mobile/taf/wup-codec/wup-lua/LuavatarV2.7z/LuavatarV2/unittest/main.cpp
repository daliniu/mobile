#include <iostream>
#include "servant/Application.h"
#include "util/tc_option.h"
#include "TestLuaState.hpp"
#include "TestFunc.hpp"
#include "TestClass.hpp"
#include "TestStruct.hpp"
#include "TestJceCpp.hpp"

using namespace std;

#define USING_MACHINELIB

void showHelp()
{
    cout<<"Usage:"<<endl;
    cout<<"luavatartest --case=string"<<endl;
    exit(0);
}

struct A
{
    int a;
};

int main(int argc, char *argv[])
{
    try
	{
        ///////////////////////////////////////////////////////////////////////////
        TC_Option op;
        op.decode(argc, argv);

        if(op.hasParam("case"))
        {
           string sCase = op.getValue("case");
           if(sCase == "s")
           {
               TestLuaStateNotOwner();
           }
           else if(sCase == "f")
           {
               TestFunction();
           }
           else if(sCase == "c")
           {
               TestClassWrapping();
           }
           else if(sCase == "d")
           {

                TestStructWrapping();
           }
           else if(sCase == "j")
           {
                TestJceCpp();
           }
           else if(sCase == "t")
           {
               A a1,a2,a3;
               a1.a=10;
               a2.a=11;
               a3.a=12;

               vector<A> va;
               va.push_back(a1);
               va.push_back(a2);
               va.push_back(a3);
                
               cout<<"#################"<<endl;
               A* pa1=&va[0];
               cout<<pa1->a<<endl;

               map<string,A> ma;
               ma.insert(make_pair("a1",a1));
               ma.insert(make_pair("a2",a2));
               ma.insert(make_pair("a3",a3));

               pa1=&ma["a1"];
               cout<<pa1->a<<endl;
           }
        }
        else
        {
            showHelp();
        }
        
	}
	catch(exception &ex)
	{
        cout << ex.what() << endl;
        exit(0);
	}

	return 0;
}

