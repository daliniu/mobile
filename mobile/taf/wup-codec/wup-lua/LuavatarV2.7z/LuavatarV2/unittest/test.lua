require "util.printr"
local array = require "util.array"
local print_r = print_r

a=array();
a:push("1");
a:push("2");
a:push("3");
print(a);

--a:pop(1);
--print(a:length());
--print(a);

local b = array();
b:push("5555");
b:push("5555");
b:push("5555");
b:push("6666");
b:push("777");
b:push("88");
b:push("9");

a:append(b);
print(a);

a:sort(function(c,d) return #c<#d; end);
print(a);
print_r(a)
--return b1:set_b(a)

paramIn={}
paramIn.a=1
paramIn.b="string b"


nestS={}
nestS.aa=45678
nestS.bb="rtyy"

paramIn.c=nestS

print_r(paramIn)
