#include "iostream"
#include "luastate.h"

using namespace std;

// - TestLuaStateNotOwner ------------------------------------------------------
void TestLuaStateNotOwner()
{
   using namespace Luavatar;

   lua_State* rls; // raw Lua state

   rls = luaL_newstate();
   //luaL_openlibs (rls);

   lua_pushstring (rls, "x");
   //unsigned int uin=2202004065;
   //lua_pushnumber (rls, uin);
   string ss="ssssss";
   lua_pushlstring (rls, ss.c_str(),ss.length());
   lua_settable (rls, LUA_GLOBALSINDEX);

   {
      LuaState ls (rls,true);

      //cout<<"ls[x]=171("<<(ls["x"].value().asInteger()==171)<<")"<<endl;
      cout<<"ls[x]=2202004065("<<(ls["x"].value().asString())<<")"<<endl;
      ls.doString ("y = 555");
      cout<<ls["y"].value().asNumber()<<endl;

      //LuaState ls2;
      //ls2["s"] = 5;
      ls["s"] = "ssssssss";
      cout<<ls["s"].value().asString()<<endl;

      ls.doFile("test.lua");
      cout<<"Table:"<<ls["paramIn"]["a"].value().asInteger()<<endl;
      cout<<"Table:"<<ls["paramIn"]["b"].value().asString()<<endl;
      cout<<"Table:"<<ls["paramIn"]["c"]["aa"].value().asInteger()<<endl;
      cout<<"Table:"<<ls["paramIn"]["c"]["bb"].value().asString()<<endl;

      ls["paramIn"]["a"]=6;
      ls["paramIn"]["b"]="modified string.";
      ls["paramIn"]["c"]["aa"]=1234;
      ls["paramIn"]["c"]["bb"]="oiu";
      cout<<"Table Modified:"<<ls["paramIn"]["a"].value().asInteger()<<endl;
      cout<<"Table Modified:"<<ls["paramIn"]["b"].value().asString()<<endl;
      cout<<"Table:"<<ls["paramIn"]["c"]["aa"].value().asInteger()<<endl;
      cout<<"Table:"<<ls["paramIn"]["c"]["bb"].value().asString()<<endl;

      cout<<"###############################"<<endl;

      cout<<ls["a"][1].value().asString()<<endl;
      cout<<ls["a"][4].value().asString()<<endl;
      cout<<ls["a"][6].value().asString()<<endl;
      cout<<ls["a"][10].value().asString()<<endl;

      cout<<endl;
      ls["a"][1]="9";
      ls["a"][4]="10";
      ls["a"][6]="11";
      ls["a"][10]="12";

      cout<<ls["a"][1].value().asString()<<endl;
      cout<<ls["a"][4].value().asString()<<endl;
      cout<<ls["a"][6].value().asString()<<endl;
      cout<<ls["a"][10].value().asString()<<endl;

      cout<<"###############################"<<endl;
   }

   lua_pushstring (rls, "y");
   lua_gettable (rls, LUA_GLOBALSINDEX);

   cout<<lua_isnumber (rls, -1)<<endl;
   cout<<"lua_tonumber(rls, -1) == 555("<<(lua_tonumber(rls, -1) == 555)<<")"<<endl;

}
