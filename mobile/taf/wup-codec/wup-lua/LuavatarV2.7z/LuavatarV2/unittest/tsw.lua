require "util.printr"
local array = require"util.array"

print_r(aPerson:get_vHoner())
print(aPerson:get_vHoner(1))
print(aPerson:get_vHoner(2))
print(aPerson:get_vHoner(3))

print("now test set vector<string> single way...")
aPerson:set_vHoner(1,"cute boy")
aPerson:set_vHoner(3,"agly man")
print_r(aPerson:get_vHoner())

print("now test set vector<string> batch way...")
array_honer = array()
array_honer:push("boy boy go")
array_honer:push("girl girl go")
array_honer:push("man man back")
aPerson:set_vHoner(array_honer)
print_r(aPerson:get_vHoner())

print_r(aPerson:get_vHistoryAcct())
print(aPerson:get_vHistoryAcct(1):get_dwBalance())
print(aPerson:get_vHistoryAcct(2):get_dwBalance())
print(aPerson:get_vHistoryAcct(3):get_dwBalance())
print(aPerson:get_vHistoryAcct(4):get_dwBalance())

print("now test set vector<struct> single way...")
aPerson:get_vHistoryAcct(1):set_dwBalance(666)
aPerson:get_vHistoryAcct(2):set_dwBalance(7777)
aPerson:get_vHistoryAcct(3):set_dwBalance(88888)
aPerson:get_vHistoryAcct(4):set_dwBalance(999999)
print_r(aPerson:get_vHistoryAcct())
print(aPerson:get_vHistoryAcct(1):get_dwBalance())
print(aPerson:get_vHistoryAcct(2):get_dwBalance())
print(aPerson:get_vHistoryAcct(3):get_dwBalance())
print(aPerson:get_vHistoryAcct(4):get_dwBalance())


print("#####################################")
print_r(aPerson:get_vDecends())
print("now let's test set vector<vector> single way...")
local dec1 = array()
dec1:push("mom-1-1")
dec1:push("dad-1-2")
dec1:push("son-1-3")

local dec3 = array()
dec3:push("mom-3-1")
dec3:push("dad-3-2")
dec3:push("son-3-3")
--print_r(dec1)
aPerson:set_vDecends(1,dec1)
aPerson:set_vDecends(3,dec3)
print_r(aPerson:get_vDecends())

print("now let's test set vector<vector> batch way...")
local dec1 = array()
dec1:push("mom-1-1")
dec1:push("dad-1-2")
dec1:push("son-1-3")

local dec2 = array()
dec2:push("mom-2-1")
dec2:push("dad-2-2")
dec2:push("son-2-3")

local dec3 = array()
dec3:push("mom-3-1")
dec3:push("dad-3-2")
dec3:push("son-3-3")

local dec = array();
dec:push(dec1)
dec:push(dec2)
dec:push(dec3)
aPerson:set_vDecends(dec)
print_r(aPerson:get_vDecends())

print("#######################################")
print_r(aPerson:get_mpPrice())

print("now let's test map single way...")
aPerson:set_mpPrice("ear",999.89)
aPerson:set_mpPrice("head",88.98)
--now add a new elements
aPerson:set_mpPrice("legs",77.98)
print_r(aPerson:get_mpPrice())

print("now let's test map batch way...")
local myprice={}
myprice.ear=123
myprice.head=456
myprice.legs=980
myprice.arms=765
aPerson:set_mpPrice(myprice)
print_r(aPerson:get_mpPrice())

print("#######################################")
local familyAcct = aPerson:get_mpFamilyAcct()
print_r(familyAcct)
print( "son:" .. familyAcct["son"]:get_dwBalance() .. '|mom:' .. familyAcct["mom"]:get_dwBalance() .. '|dad:' .. familyAcct["dad"]:get_dwBalance())
print("now let's test set map<struct> single way...")
aPerson:get_mpFamilyAcct("son"):set_dwBalance(777)
aPerson:get_mpFamilyAcct("dad"):set_dwBalance(8888)
aPerson:get_mpFamilyAcct("mom"):set_dwBalance(99999)
familyAcct = aPerson:get_mpFamilyAcct()
print_r(familyAcct)
print( "son:" .. familyAcct["son"]:get_dwBalance() .. '|mom:' .. familyAcct["mom"]:get_dwBalance() .. '|dad:' .. familyAcct["dad"]:get_dwBalance())

print("#######################################")
local familyAgeAcct = aPerson:get_mpFamilyAgeAcct()
print_r(familyAgeAcct)
print("1981-mom:" .. familyAgeAcct[1981]["mom"]:get_dwBalance() .. "|1981-dad:" .. familyAgeAcct[1981]["dad"]:get_dwBalance() .. "|1981-son:" .. familyAgeAcct[1981]["son"]:get_dwBalance())
print("1991-mom:" .. familyAgeAcct[1991]["mom"]:get_dwBalance() .. "|1991-dad:" .. familyAgeAcct[1991]["dad"]:get_dwBalance() .. "|1991-son:" .. familyAgeAcct[1991]["son"]:get_dwBalance())
print("2011-mom:" .. familyAgeAcct[2011]["mom"]:get_dwBalance() .. "|2011-dad:" .. familyAgeAcct[2011]["dad"]:get_dwBalance() .. "|2011-son:" .. familyAgeAcct[2011]["son"]:get_dwBalance())
print("now let's test set map in map single way...")
a1981=aPerson:get_mpFamilyAgeAcct(1981)
a1991=aPerson:get_mpFamilyAgeAcct(1991)
a2011=aPerson:get_mpFamilyAgeAcct(2011)

aPerson:set_mpFamilyAgeAcct(1981,a1991)
aPerson:set_mpFamilyAgeAcct(1991,a2011)
aPerson:set_mpFamilyAgeAcct(2011,a1981)

familyAgeAcct = aPerson:get_mpFamilyAgeAcct()
print_r(familyAgeAcct)
print("1981-mom:" .. familyAgeAcct[1981]["mom"]:get_dwBalance() .. "|1981-dad:" .. familyAgeAcct[1981]["dad"]:get_dwBalance() .. "|1981-son:" .. familyAgeAcct[1981]["son"]:get_dwBalance())
print("1991-mom:" .. familyAgeAcct[1991]["mom"]:get_dwBalance() .. "|1991-dad:" .. familyAgeAcct[1991]["dad"]:get_dwBalance() .. "|1991-son:" .. familyAgeAcct[1991]["son"]:get_dwBalance())
print("2011-mom:" .. familyAgeAcct[2011]["mom"]:get_dwBalance() .. "|2011-dad:" .. familyAgeAcct[2011]["dad"]:get_dwBalance() .. "|2011-son:" .. familyAgeAcct[2011]["son"]:get_dwBalance())

print("now let's test set map in map batch way...")
a1981=aPerson:get_mpFamilyAgeAcct(1981)
a1991=aPerson:get_mpFamilyAgeAcct(1991)
a2011=aPerson:get_mpFamilyAgeAcct(2011)

allage={}
allage[1981]=a1991
allage[1991]=a2011
allage[2011]=a1981
aPerson:set_mpFamilyAgeAcct(allage)

familyAgeAcct = aPerson:get_mpFamilyAgeAcct()
print_r(familyAgeAcct)
print("1981-mom:" .. familyAgeAcct[1981]["mom"]:get_dwBalance() .. "|1981-dad:" .. familyAgeAcct[1981]["dad"]:get_dwBalance() .. "|1981-son:" .. familyAgeAcct[1981]["son"]:get_dwBalance())
print("1991-mom:" .. familyAgeAcct[1991]["mom"]:get_dwBalance() .. "|1991-dad:" .. familyAgeAcct[1991]["dad"]:get_dwBalance() .. "|1991-son:" .. familyAgeAcct[1991]["son"]:get_dwBalance())
print("2011-mom:" .. familyAgeAcct[2011]["mom"]:get_dwBalance() .. "|2011-dad:" .. familyAgeAcct[2011]["dad"]:get_dwBalance() .. "|2011-son:" .. familyAgeAcct[2011]["son"]:get_dwBalance())

