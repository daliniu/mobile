require "util.printr"

--amt={}
--amt.__call=function(a,b) print(b) end
--setmetatable(Account,amt)
--print("aaaaaaa")
print("########Account Class table########")
print_r(Account)

print("##########Account Class meta table########")
print_r(getmetatable(Account))

print("*************")
a3 = Account(250)
print("a3 = " .. a3:balance())
a8 = Account:new(12)
print("a8 = " .. a8:balance())
--a9 = Account.new(13) --������÷�
--print("a9 = " .. a9:balance())
print("##########Account Object meta table#############")
print_r(getmetatable(a8))
--print_r(getmetatable(a9))

