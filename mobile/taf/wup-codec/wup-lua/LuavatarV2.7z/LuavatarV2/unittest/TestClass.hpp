#include <iostream>
#include "luastate.h"
#include "WrappedClasses.hpp"

using namespace std;

// - TestClassWrapping ---------------------------------------------------------
void TestClassWrapping()
{
   using namespace Luavatar;
   LuaState ls;

   // First, make the desired class available in our 'LuaState'
   REGISTER_CLASS(Account, ls);

   // In Lua, create two instances of the class and call some methods
   cout<<"PreCondition(a1 = Account:new(),a2 = Account:new(123.45)):"<<endl;
   ls.doString ("a1 = Account:new(20)");
   ls.doString ("a2 = Account:new(123.45)");
   //ls.doString ("a3 = Account(250)");

   ls.doFile ("tbf.lua");
   
   cout<<"Case 1(return a1:balance()):"<<endl;
   Luavatar::LuaValueList ret = ls.doString ("return a1:balance()");
   cout<<"ret.size() ="<<ret.size()<<endl;
   cout<<"ret[0].type() ="<<ret[0].typeName()<<endl;
   cout<<"ret[0] ="<<ret[0].asNumber()<<endl<<endl;
   
   cout<<"Case 2(return a2:balance()):"<<endl;
   ret = ls.doString ("return a2:balance()");
   cout<<"ret.size() ="<<ret.size()<<endl;
   cout<<"ret[0].type() ="<<ret[0].typeName()<<endl;
   cout<<"ret[0] ="<<ret[0].asNumber()<<endl<<endl;
   
   cout<<"Case 3(a1:deposit (55.66)):"<<endl;
   ls.doString ("a1:deposit (55.66)");
   ret = ls.doString ("return a1:balance()");
   cout<<"ret.size() ="<<ret.size()<<endl;
   cout<<"ret[0].type() ="<<ret[0].typeName()<<endl;
   cout<<"ret[0] ="<<ret[0].asNumber()<<endl<<endl;
   
   cout<<"Case 4(a1:withdraw (15.66)):"<<endl;
   ls.doString ("a1:withdraw (15.66)");
   ret = ls.doString ("return a1:balance()");
   cout<<"ret.size() ="<<ret.size()<<endl;
   cout<<"ret[0].type() ="<<ret[0].typeName()<<endl;
   cout<<"ret[0] ="<<ret[0].asNumber()<<endl<<endl;
   
   cout<<"Case 5(a2:withdraw (0.45)):"<<endl;
   ls.doString ("a2:withdraw (0.45)");
   ret = ls.doString ("return a2:balance()");
   cout<<"ret.size() ="<<ret.size()<<endl;
   cout<<"ret[0].type() ="<<ret[0].typeName()<<endl;
   cout<<"ret[0] ="<<ret[0].asNumber()<<endl<<endl;

   // Now, create an instance in C++, make it available in our 'LuaState', call
   // its methods in Lua and C++, and check if the things really change on the
   // other side
   cout<<"Precondition(Account aCppAccount (params,50.0)):"<<endl;
   LuaValueList params;
   params.push_back (50.0);
   Account aCppAccount (params);

   //LUAVATAR_REGISTER_OBJECT (ls["a3"], Account, aCppAccount);
   REGISTER_OBJ(ls["a3"],Account,&aCppAccount);
   
   cout<<"Case 6(a3:deposit (50.0)):"<<endl;
   ls.doString ("a3:deposit (50.0)");
   LuaValueList values;
   int iRet = aCppAccount.balance(LuaValueList(),values);
   cout<<"aCppAccount.balance (LuaValueList())[0] ="<<iRet<<"|"<<values[0].typeName()<<"|"<<values[0].asNumber()<<endl<<endl;
   
   cout<<"Case 7(aCppAccount.withdraw (params,110.0),return a3:balance()):"<<endl;
   params.clear();
   params.push_back (110.0);
   iRet =  aCppAccount.withdraw (params,values);
   ret = ls.doString ("return a3:balance()");
   cout<<"ret.size() ="<<ret.size()<<endl;
   cout<<"ret[0] ="<<ret[0].asNumber()<<endl<<endl;

   //���濪ʼ����userdata�ĵ�������
   cout<<"Case 8(ls[\"a1\"]):"<<endl;
   //cout<<"ls[\"a1\"].value().type()="<<ls["a1"].value().typeName()<<endl;
   cout<<ls["a1"].value().typeName()<<endl;
   LuaUserDataTypeWrapper udw=ls["a1"].value().asUserData();
   Luavatar::LuaValue::CppObject* ptrCo = static_cast<Luavatar::LuaValue::CppObject*>(udw.ptr);
   Account* y = static_cast<Account*>(ptrCo->ptr); 
   //Account* y = ls["a1"].value().asObjectPtr<Account*>(); 
   params.clear();
   values.clear();
   iRet = y->balance(params,values);
   cout<<"a1:"<<iRet<<"|"<<values[0].asNumber()<<endl;

   params.clear();
   values.clear();
   ret.clear();
   params.push_back(30.5);
   iRet = y->withdraw(params,values);
   ret = ls.doString("return a1:balance()");
   cout<<ret.size()<<"|"<<ret[0].asNumber()<<endl;
#if 0
   cout<<"rigth addr:"<<y<<"|"<<(y->balance(LuaValueList())[0]).asNumber()<<endl;
   //cout<<b2s((const char*)(static_cast<CppObject*>(ls["a1"].value().asUserData().getData())),sizeof(CppObject))<<endl;
	
   /*
   char o[5];
   memcpy(o,ls["a1"].value().asUserData().getData(),5);
   //Luavatar::CppObject* p = static_cast<CppObject*>((void*)&o[0]);
   Luavatar::CppObject* p = new(o) Luavatar::CppObject;
*/
   //wired...
   //Luavatar::CppObject* p = static_cast<CppObject*>(ls["a1"].value().asUserData().getData());
   Luavatar::CppObject* p = static_cast<CppObject*>((void *)ls["a1"].value().asUserData().getData());
   cout<<b2s((const char*)(p),sizeof(CppObject))<<endl;
   //cout<<static_cast<CppObject*>(ls["a1"].value().asUserData().getData())->ptr<<"|"<<p->ptr<<endl;
   //Account* q = static_cast<Account*>(p->ptr);  //wired.....
   //Account* q = static_cast<Account*>(static_cast<CppObject*>(ls["a1"].value().asUserData().getData())->ptr);
   //cout<<"ls[\"a1\"].value().asUserData.getData()="<<static_cast<Account*>(p->ptr)<<"|"<<p->deleteMe<<"|"<<q<<endl;
   Account* q = ls["a1"].value().asObjectPtr<Account*>();
   cout<<"ls[\"a1\"].value().asObjectPtr()="<<(q->balance(LuaValueList())[0]).asNumber()<<endl;
#endif
}
