#include <iostream>
#include "luastate.h"

using namespace std;

// - TestFunctionWrapping ------------------------------------------------------
void TestFunction()
{
   using namespace Luavatar;
   LuaState ls;

   LuaValueList param;
   LuaValueList values;
   param.clear();
   values.clear();

   ls.doFile("testfunc.lua");
   cout<<"####################"<<endl;
   int iRet = ls.call("foo0",param,values);
   cout<<"foo0:"<<iRet<<"|"<<values.size()<<endl;

   iRet = ls.call("foo1",param,values);
   cout<<"foo1:"<<iRet<<"|"<<values.size()<<"|"<<values[0].asString()<<endl;

   iRet = ls.call("foo2",param,values);
   cout<<"foo1:"<<iRet<<"|"<<values.size()<<"|"<<values[0].asString()<<"|"<<values[1].asString()<<endl;

   param.push_back(LuaValue(1));
   param.push_back(LuaValue(2));
   iRet = ls.call("foo3",param,values);
   cout<<"foo3:"<<iRet<<"|"<<values.size()<<"|"<<values[0].asInteger()<<"|"<<values[1].asInteger()<<endl;
   cout<<"####################"<<endl;

   iRet = ls["func_arry"]["f0"](param,values);
   cout<<"array foo0:"<<iRet<<"|"<<values.size()<<endl;

   iRet = ls["func_arry"]["f1"](param,values);
   cout<<"array foo1:"<<iRet<<"|"<<values.size()<<"|"<<values[0].asString()<<endl;

   iRet = ls["func_arry"]["f2"](param,values);
   cout<<"array foo1:"<<iRet<<"|"<<values.size()<<"|"<<values[0].asString()<<"|"<<values[1].asString()<<endl;

   param.clear();
   param.push_back(LuaValue(2202004065));
   param.push_back(LuaValue(2202004065));
   iRet = ls["func_arry"]["f3"](param,values);
   cout<<"array foo3:"<<iRet<<"|"<<values.size()<<"|"<<values[0].asInteger64()<<"|"<<values[1].asInteger64()<<endl;
   cout<<"####################"<<endl;
}

