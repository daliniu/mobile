require "util.printr"

--[[
print("Before:")
print(aPerson:get_strName())
print(aPerson:get_iAge())
print(aPerson:get_stOwnAcct():get_dwBalance())
print("###################")
aPerson:set_strName("falice")
aPerson:set_iAge(47)
aPerson:get_stOwnAcct():set_dwBalance(10000000)
print("After:")
print(aPerson:get_strName())
print(aPerson:get_iAge())
print(aPerson:get_stOwnAcct():get_dwBalance())
print("###################")
print("batch...")
print_r(aPerson:get_vHoner())

print("single...")
print(aPerson:get_vHoner(3))
print(aPerson:get_vHoner(2))
print(aPerson:get_vHoner(1))

print("vector<struct> test...")
print("batch...")
print(aPerson:get_vHistoryAcct()[1]:get_dwBalance())
print(aPerson:get_vHistoryAcct()[2]:get_dwBalance())
print(aPerson:get_vHistoryAcct()[3]:get_dwBalance())
print(aPerson:get_vHistoryAcct()[4]:get_dwBalance())
--print(aPerson:get_vHistoryAcct()[5]:get_dwBalance())

print("single...")
print(aPerson:get_vHistoryAcct(4):get_dwBalance())
print(aPerson:get_vHistoryAcct(3):get_dwBalance())
print(aPerson:get_vHistoryAcct(2):get_dwBalance())
print(aPerson:get_vHistoryAcct(1):get_dwBalance())
--print(aPerson:get_vHistoryAcct(5):get_dwBalance())

print("now let's test vector in vector")
decends = aPerson:get_vDecends()
print_r(decends)

print_r(aPerson:get_vDecends(3))
print_r(aPerson:get_vDecends(2))
print_r(aPerson:get_vDecends(1))

print("now let's test map")
allprice = aPerson:get_mpPrice()
print_r(allprice)

print(aPerson:get_mpPrice("mouth"))
print(aPerson:get_mpPrice("arms"))
print(aPerson:get_mpPrice("legs"))

print("now let's test struct in map")
familyAcct = aPerson:get_mpFamilyAcct()
print_r(familyAcct)
print(familyAcct["son"]:get_dwBalance() .. '|' .. familyAcct["mom"]:get_dwBalance() .. '|' .. familyAcct["dad"]:get_dwBalance())

print(aPerson:get_mpFamilyAcct("dad"):get_dwBalance())
print(aPerson:get_mpFamilyAcct("son"):get_dwBalance())
print(aPerson:get_mpFamilyAcct("mom"):get_dwBalance())

print("now let's test map in map")
familyAgeAcct = aPerson:get_mpFamilyAgeAcct()
print_r(familyAgeAcct)
print(familyAgeAcct[2011]["mom"]:get_dwBalance() .. "|" .. familyAgeAcct[2011]["dad"]:get_dwBalance() .. "|" .. familyAgeAcct[2011]["son"]:get_dwBalance())

print(aPerson:get_mpFamilyAgeAcct(2011)["mom"]:get_dwBalance())
print(aPerson:get_mpFamilyAgeAcct(1991)["mom"]:get_dwBalance())
print(aPerson:get_mpFamilyAgeAcct(1981)["mom"]:get_dwBalance())
--]]
