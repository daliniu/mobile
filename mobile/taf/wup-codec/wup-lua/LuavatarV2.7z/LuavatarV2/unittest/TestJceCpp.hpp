#include <iostream>
#include "luastate.h"
#include "test.h"

using namespace std;
using namespace Test;

// - TestClassWrapping ---------------------------------------------------------
void TestJceCpp()
{
   using namespace Luavatar;
   LuaState ls;


   cout<<"#####################"<<endl;
   REGISTER_STRUCT(Test::a, ls);
   REGISTER_STRUCT(Test::b, ls);
   //���Խ�ֹ��lua������structʵ��
   //ls.doString ("a1 = Account_ST:new(20)");

   Test::a aJce;
   aJce.t = 10;
   aJce.v.clear();
   aJce.v.push_back("one");
   aJce.v.push_back("two");
   aJce.v.push_back("three");

   REGISTER_OBJ(ls["aJce"],Test::a,&aJce);

   ls.doString("print(aJce:get_t())");
   ls.doString("print(aJce:get_v(1) .. ' ' ..  aJce:get_v(2) .. ' ' ..  aJce:get_v(3))");
   ls.doString("aJce:set_t(20)");
   ls.doString("aJce:set_v(1,'four')");
   ls.doString("aJce:set_v(2,'five')");
   ls.doString("aJce:set_v(3,'six')");

   cout<<"now aJce.t is:"<<aJce.t<<endl;
   cout<<"now aJce.v is:"<<aJce.v[0] << " " << aJce.v[1] << " " << aJce.v[2] <<endl;

   cout<<"##################################"<<endl;
   Test::b bJce;
   bJce._a = aJce;
   bJce._e = enTur;

   REGISTER_OBJ(ls["bJce"],Test::b,&bJce);
   ls.doString("print(bJce:get__a():get_t())");
   ls.doString("print(bJce:get__a():get_v(1) .. ' ' ..  bJce:get__a():get_v(2) .. ' ' ..  bJce:get__a():get_v(3))");
   ls.doString("print(bJce:get__e())");
}
