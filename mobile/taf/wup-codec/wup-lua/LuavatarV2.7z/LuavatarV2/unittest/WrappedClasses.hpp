#ifndef _LUAVATAR_TESTS_WRAPPED_CLASSES_HPP_
#define _LUAVATAR_TESTS_WRAPPED_CLASSES_HPP_

#include "luaregistry.h"

namespace
{
   using namespace Luavatar;
   using Luavatar::LuaValueList;

   /// The good and old \c Account class...
   class Account
   {
      DECLARE_SCRIPT_CLASS(Account)
      public:
         Account(){balance_ = 0.0;}
         Account (const LuaValueList& params)
         {
            if (params.size() == 0)
               balance_ = 0.0;
            else if (params.size() == 1 && params[0].type() == dataNumber)
               balance_ = params[0].asNumber();
            else
               throw Luavatar::LuaError ("Bad parameters!");
         }

         int deposit (const LuaValueList& params,LuaValueList& values)
         {
            if (params.size() != 1 || params[0].type() != dataNumber)
               throw Luavatar::LuaError ("Bad parameters!");

            balance_ += params[0].asNumber();

            return 0;
         }

         int withdraw (const LuaValueList& params,LuaValueList& values)
         {
            if (params.size() != 1 || params[0].type() != dataNumber)
               throw Luavatar::LuaError ("Bad parameters!");

            balance_ -= params[0].asNumber();

            return 0;
         }

         int balance (const LuaValueList& params,LuaValueList& values)
         {
            values.clear();
            values.push_back (balance_);
            return 1;
         }

      private:
         double balance_;
   };

   IMPLEMENT_SCRIPT_CLASS(Account)

   //Bind member functions to LUA
   BEGIN_SCRIPT_METHOD(Account)
     LUNAR_DECLARE_METHOD(Account, deposit),
     LUNAR_DECLARE_METHOD(Account, withdraw),
     LUNAR_DECLARE_METHOD(Account, balance),
   END_SCRIPT_METHOD

   class NumberProperties
   {
      DECLARE_SCRIPT_CLASS(NumberProperties)
      public:
         NumberProperties(){}
         NumberProperties (const LuaValueList& params)
         {
            number_ = static_cast<unsigned>(params[0].asNumber());
         }

         int isEven (const LuaValueList& params,LuaValueList& values)
         {
            values.clear();
            values.push_back (number_ % 2 == 0);
            return 1;
         }

         int isOdd (const LuaValueList& params,LuaValueList& values)
         {
            values.clear();
            values.push_back (number_ % 2 != 0);
            return 1;
         }

         int isBig (const LuaValueList& params,LuaValueList& values)
         {
            values.clear();
            values.push_back (number_ > 1000);
            return 1;
         }

      private:
         unsigned number_;
   };

   IMPLEMENT_SCRIPT_CLASS(NumberProperties)
   BEGIN_SCRIPT_METHOD(NumberProperties)
      LUNAR_DECLARE_METHOD(NumberProperties, isEven),
      LUNAR_DECLARE_METHOD(NumberProperties, isOdd),
      LUNAR_DECLARE_METHOD(NumberProperties, isBig),
   END_SCRIPT_METHOD 


   class DestructorTester
   {
      DECLARE_SCRIPT_CLASS(DestructorTester)
      public:
         static bool aFlag;

         DestructorTester () { }
         DestructorTester (const LuaValueList&) { }

         ~DestructorTester() { aFlag = true; }
   };

   bool DestructorTester::aFlag = false;

   IMPLEMENT_SCRIPT_CLASS(DestructorTester)
   BEGIN_SCRIPT_METHOD(DestructorTester)
   END_SCRIPT_METHOD

} 

#endif // _LUAVATAR_TESTS_WRAPPED_CLASSES_HPP_
