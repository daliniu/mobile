#ifndef _LUAVATAR_TESTS_WRAPPED_STRUCTS_HPP_
#define _LUAVATAR_TESTS_WRAPPED_STRUCTS_HPP_

#include "luaregistry.h"

namespace
{
   using namespace Luavatar;
   using Luavatar::LuaValueList;

   /// The good and old \c Account class...
   struct Account_ST
   {
      DECLARE_SCRIPT_STRUCT(Account_ST)
      public:
         Account_ST(){dwBalance = 0.0;}
         Account_ST (const LuaValueList& params)
         {
            if (params.size() == 0)
               dwBalance = 0.0;
            else if (params.size() == 1 && params[0].type() == dataNumber)
               dwBalance = params[0].asNumber();
            else
               throw Luavatar::LuaError ("Bad parameters!");
         }

         int get_dwBalance (lua_State* L)
         {
            return LuaAttrHelper<double>::get(L,dwBalance);
         }

         int set_dwBalance (lua_State* L)
         {
            return LuaAttrHelper<double>::set(L,dwBalance);
         }

         void cs2table(Luavatar::LuaVariable lv) const
         {
             lv.emptyTable();
             LuaAttrHelper<double>::copy(dwBalance,lv["dwBalance"]);
             return;
         }


         double dwBalance;
   };

   IMPLEMENT_SCRIPT_STRUCT(Account_ST)

   //Bind member functions to LUA
   BEGIN_SCRIPT_ATTR(Account_ST)
     LUNAR_DECLARE_ATTR(Account_ST, get_dwBalance),
     LUNAR_DECLARE_ATTR(Account_ST, set_dwBalance),
   END_SCRIPT_ATTR

    //2:person struct,contains account one
    struct Person_ST
    {
        DECLARE_SCRIPT_STRUCT(Person_ST)
        public:
            Person_ST(){}
            Person_ST(const LuaValueList& params){}

            //attributs funcs
            int get_strName(lua_State* L)
            {
                return LuaAttrHelper<string>::get(L,strName);
            }

            int set_strName(lua_State* L)
            {
                return LuaAttrHelper<string>::set(L,strName);
            }

            int get_iAge(lua_State* L)
            {
                return LuaAttrHelper<int>::get(L,iAge);
            }

            int set_iAge(lua_State* L)
            {
                return LuaAttrHelper<int>::set(L,iAge);
            }

            int get_stOwnAcct(lua_State* L)
            {
                return LuaAttrHelper<Account_ST>::get(L,stOwnAcct);
            }

            int set_stOwnAcct(lua_State* L)
            {
                return LuaAttrHelper<Account_ST>::set(L,stOwnAcct);
            }

            int get_vHoner(lua_State* L)
            {
                return LuaAttrHelper<vector<string> >::get(L,vHoner);
            }

            int set_vHoner(lua_State* L)
            {
                return LuaAttrHelper<vector<string> >::set(L,vHoner);
            }

            int get_vHistoryAcct(lua_State* L)
            {
                return LuaAttrHelper<vector<Account_ST> >::get(L,vHistoryAcct);
            }

            int set_vHistoryAcct(lua_State* L)
            {
                return LuaAttrHelper<vector<Account_ST> >::set(L,vHistoryAcct);
            }

            int get_vDecends(lua_State* L)
            {
                return LuaAttrHelper<vector<vector<string> > >::get(L,vDecends);
            }

            int set_vDecends(lua_State* L)
            {
                return LuaAttrHelper<vector<vector<string> > >::set(L,vDecends);
            }

            int get_mpPrice(lua_State* L)
            {
                return LuaAttrHelper<map<string,double> >::get(L,mpPrice);
            }

            int set_mpPrice(lua_State* L)
            {
                return LuaAttrHelper<map<string,double> >::set(L,mpPrice);
            }

            int get_mpFamilyAcct(lua_State* L)
            {
                return LuaAttrHelper<map<string,Account_ST> >::get(L,mpFamilyAcct);
            }

            int set_mpFamilyAcct(lua_State* L)
            {
                return LuaAttrHelper<map<string,Account_ST> >::set(L,mpFamilyAcct);
            }

            int get_mpFamilyAgeAcct(lua_State* L)
            {
                return LuaAttrHelper<map<int,map<string,Account_ST> > >::get(L,mpFamilyAgeAcct);
            }

            int set_mpFamilyAgeAcct(lua_State* L)
            {
                return LuaAttrHelper<map<int,map<string,Account_ST> > >::set(L,mpFamilyAgeAcct);
            }
            void cs2table(Luavatar::LuaVariable lv) const
            {
                lv.emptyTable();
                LuaAttrHelper<string>::copy(strName,lv["strName"]);
                LuaAttrHelper<int>::copy(iAge,lv["iAge"]);
                LuaAttrHelper<Account_ST>::copy(stOwnAcct,lv["stOwnAcct"]);
                LuaAttrHelper<vector<string> >::copy(vHoner,lv["vHoner"]);
                LuaAttrHelper<map<string,double> >::copy(mpPrice,lv["mpPrice"]);
                LuaAttrHelper<map<string,Account_ST> >::copy(mpFamilyAcct,lv["mpFamilyAcct"]);
                LuaAttrHelper<map<int,map<string,Account_ST> > >::copy(mpFamilyAgeAcct,lv["mpFamilyAgeAcct"]);

                return;
            }
        ///////////////////////
        string          strName;
        int             iAge;
        Account_ST      stOwnAcct;
        vector<string>  vHoner;
        vector<Account_ST> vHistoryAcct;
        vector<vector<string> > vDecends;
        map<string,double> mpPrice;
        map<string,Account_ST> mpFamilyAcct;
        map<int,map<string,Account_ST> > mpFamilyAgeAcct;
    };

   IMPLEMENT_SCRIPT_STRUCT(Person_ST)
   BEGIN_SCRIPT_ATTR(Person_ST)
     LUNAR_DECLARE_ATTR(Person_ST, get_strName),
     LUNAR_DECLARE_ATTR(Person_ST, set_strName),
     LUNAR_DECLARE_ATTR(Person_ST, get_iAge),
     LUNAR_DECLARE_ATTR(Person_ST, set_iAge),
     LUNAR_DECLARE_ATTR(Person_ST, get_stOwnAcct),
     LUNAR_DECLARE_ATTR(Person_ST, set_stOwnAcct),
     LUNAR_DECLARE_ATTR(Person_ST, get_vHoner),
     LUNAR_DECLARE_ATTR(Person_ST, set_vHoner),
     LUNAR_DECLARE_ATTR(Person_ST, get_vHistoryAcct),
     LUNAR_DECLARE_ATTR(Person_ST, set_vHistoryAcct),
     LUNAR_DECLARE_ATTR(Person_ST, get_vDecends),
     LUNAR_DECLARE_ATTR(Person_ST, set_vDecends),
     LUNAR_DECLARE_ATTR(Person_ST, get_mpPrice),
     LUNAR_DECLARE_ATTR(Person_ST, set_mpPrice),
     LUNAR_DECLARE_ATTR(Person_ST, get_mpFamilyAcct),
     LUNAR_DECLARE_ATTR(Person_ST, set_mpFamilyAcct),
     LUNAR_DECLARE_ATTR(Person_ST, get_mpFamilyAgeAcct),
     LUNAR_DECLARE_ATTR(Person_ST, set_mpFamilyAgeAcct),
   END_SCRIPT_ATTR
} 

#endif // _LUAVATAR_TESTS_WRAPPED_STRUCTS_HPP_
