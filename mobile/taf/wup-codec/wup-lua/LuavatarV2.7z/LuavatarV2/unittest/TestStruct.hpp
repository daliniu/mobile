#include <iostream>
#include "luastate.h"
#include "WrappedStructs.hpp"

using namespace std;

// - TestClassWrapping ---------------------------------------------------------
void TestStructWrapping()
{
   using namespace Luavatar;
   LuaState ls;

   REGISTER_STRUCT(Account_ST, ls);

   cout<<"#####################"<<endl;
   //���Խ�ֹ��lua������structʵ��
   //ls.doString ("a1 = Account_ST:new(20)");

   Account_ST aAccount;
   aAccount.dwBalance = 20;

   REGISTER_OBJ(ls["aAccount"],Account_ST,&aAccount);

   ls.doString("print(aAccount:get_dwBalance())");
   ls.doString("aAccount:set_dwBalance(35.35)");

   cout<<"now balance is:"<<aAccount.dwBalance<<endl;

   //������copy
   //ls.doString("account_table = {}");
   aAccount.cs2table(ls["account_table"]);

   cout<<"###########################"<<endl;
   Person_ST aPerson;
   aPerson.strName="forrestliu";
   aPerson.iAge=29;
   aPerson.stOwnAcct.dwBalance = 50.0;

   REGISTER_STRUCT(Person_ST, ls);
   REGISTER_OBJ(ls["aPerson"],Person_ST,&aPerson);

   ls.doString("print(aPerson:get_strName() .. '|' .. aPerson:get_iAge())");
   //ls.doString("aPerson:set_strName(\"alicewang\");aPerson:set_iAge(28);");
   ls.doString("aPerson:set_strName('alicewang');aPerson:set_iAge(28);");

   cout << "now person info:"<<aPerson.strName<<"|"<<aPerson.iAge<<endl;

   ls.doString("print(aPerson:get_stOwnAcct():get_dwBalance())");
   ls.doString("aPerson:get_stOwnAcct():set_dwBalance(890.22)");

   cout<< "now person's account info:"<<aPerson.stOwnAcct.dwBalance<<endl;


   cout<< "test vector..." << endl;
   aPerson.vHoner.clear();
   aPerson.vHoner.push_back("good boy");
   aPerson.vHoner.push_back("bad girl");
   aPerson.vHoner.push_back("sexy man");

   
   aPerson.vHistoryAcct.clear();
   aAccount.dwBalance=1.0;
   aPerson.vHistoryAcct.push_back(aAccount);

   aAccount.dwBalance=100.0;
   aPerson.vHistoryAcct.push_back(aAccount);

   aAccount.dwBalance=1000.0;
   aPerson.vHistoryAcct.push_back(aAccount);

   aAccount.dwBalance=10000.0;
   aPerson.vHistoryAcct.push_back(aAccount);

   cout<<"now let's test vector in vector"<<endl<<endl;
   aPerson.vDecends.clear();

   vector<string> vFamily;
   vFamily.clear();
   vFamily.push_back("mom-1");
   vFamily.push_back("dad-1");
   vFamily.push_back("son-1");
   aPerson.vDecends.push_back(vFamily);

   vFamily.clear();
   vFamily.push_back("mom-2");
   vFamily.push_back("dad-2");
   vFamily.push_back("son-2");
   aPerson.vDecends.push_back(vFamily);

   vFamily.clear();
   vFamily.push_back("mom-3");
   vFamily.push_back("dad-3");
   vFamily.push_back("son-3");
   aPerson.vDecends.push_back(vFamily);

   cout<<"now let's test map"<<endl<<endl;
   aPerson.mpPrice.clear();
   aPerson.mpPrice.insert(make_pair("ear",10.0));
   aPerson.mpPrice.insert(make_pair("nose",20.0));
   aPerson.mpPrice.insert(make_pair("mouth",30.5));
   aPerson.mpPrice.insert(make_pair("head",60.5));
   aPerson.mpPrice.insert(make_pair("arms",90.3));

   //test struct in map
   aPerson.mpFamilyAcct.clear();
   aAccount.dwBalance=0.0;
   aPerson.mpFamilyAcct.insert(make_pair("son",aAccount));
   
   aAccount.dwBalance=10.0;
   aPerson.mpFamilyAcct.insert(make_pair("dad",aAccount));
   
   aAccount.dwBalance=10000;
   aPerson.mpFamilyAcct.insert(make_pair("mom",aAccount));

   //test map in map
   aPerson.mpFamilyAgeAcct.clear();
   map<string,Account_ST> familyAcct;

   familyAcct.clear();
   aAccount.dwBalance=0.0;
   familyAcct.insert(make_pair("son",aAccount));
   aAccount.dwBalance=10.0;
   familyAcct.insert(make_pair("dad",aAccount));
   aAccount.dwBalance=100.0;
   familyAcct.insert(make_pair("mom",aAccount));
   aPerson.mpFamilyAgeAcct.insert(make_pair(1981,familyAcct));

   familyAcct.clear();
   aAccount.dwBalance=20.0;
   familyAcct.insert(make_pair("son",aAccount));
   aAccount.dwBalance=200.0;
   familyAcct.insert(make_pair("dad",aAccount));
   aAccount.dwBalance=2000.0;
   familyAcct.insert(make_pair("mom",aAccount));
   aPerson.mpFamilyAgeAcct.insert(make_pair(1991,familyAcct));
   
   familyAcct.clear();
   aAccount.dwBalance=30000.0;
   familyAcct.insert(make_pair("son",aAccount));
   aAccount.dwBalance=400000.0;
   familyAcct.insert(make_pair("dad",aAccount));
   aAccount.dwBalance=5000000.0;
   familyAcct.insert(make_pair("mom",aAccount));
   aPerson.mpFamilyAgeAcct.insert(make_pair(2011,familyAcct));

   //ls.doFile("ts.lua");
   ls.doFile("tsw.lua");


   cout<<"xxxxxxxxxxxxxxxxxxxx"<<endl;
   aPerson.cs2table(ls["person_table"]);
   ls.doFile("tscs2table.lua");
}
