require "util.printr"
local array = require "util.array"
local print_r = print_r

function foo0 () end                  -- returns no results
function foo1 () return 'a' end       -- returns 1 result
function foo2 () return 'a','b' end   -- returns 2 results
function foo3 (a,b) return a+1,b+1 end --two arg to value

func_arry={}
func_arry.f0=foo0
func_arry.f1=foo1
func_arry.f2=foo2
func_arry.f3=foo3

print_r(func_arry)

