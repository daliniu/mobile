#include <assert.h>
#include <cstring>
#include "luavalue.h"
#include "luaexception.h"


namespace Luavatar
{
    // - LuaValue::LuaValue -----------------------------------------------------
    LuaValue::LuaValue()
    : eType(dataNil)
    {
        //do nothing
    }


    LuaValue::LuaValue (bool b)
    : eType(dataBoolean)
    {
        this->booleanNode.bValue = b;
    }

    LuaValue::LuaValue (float n)
    : eType(dataNumber)
    {
        this->numNode.nValue = n;
    }


    LuaValue::LuaValue (double n)
    : eType(dataNumber)
    {
        this->numNode.nValue = n;
    }


    LuaValue::LuaValue (long double n)
    : eType(dataNumber)
    {
        this->numNode.nValue = n;
    }


    LuaValue::LuaValue (short n)
    : eType(dataNumber)
    {
        this->numNode.nValue= n;
    }


    LuaValue::LuaValue (unsigned short n)
    : eType(dataNumber)
    {
        this->numNode.nValue= n;
    }


    LuaValue::LuaValue (int n)
    : eType(dataNumber)
    {
        this->numNode.nValue= n;
    }


    LuaValue::LuaValue (unsigned int n)
    : eType(dataNumber)
    {
        this->numNode.nValue= n;
    }


    LuaValue::LuaValue (long n)
    : eType(dataNumber)
    {
        this->numNode.nValue= n;
    }



    LuaValue::LuaValue (unsigned long n)
    : eType(dataNumber)
    {
        this->numNode.nValue= n;
    }


    LuaValue::LuaValue (long long n)
    : eType(dataNumber)
    {
        this->numNode.nValue = n;
    }


    LuaValue::LuaValue (const std::string& s)
    : eType(dataString)
    {
        if(s.length()>=SCRIPT_MAXSIZE_STRING)
        {
            throw LuaStringError("String length exceed max string Size");
        }

        memset(this->strNode.strvar,0,sizeof(this->strNode.strvar));
        memcpy(this->strNode.strvar,s.c_str(),s.length());
    }

    LuaValue::LuaValue (const char* s)
    : eType(dataString)
    {
        if(strlen(s)>=SCRIPT_MAXSIZE_STRING)
        {
            throw LuaStringError("String length exceed max string Size");
        }

        memset(this->strNode.strvar,0,sizeof(this->strNode.strvar));
        strncpy(this->strNode.strvar,s,SCRIPT_MAXSIZE_STRING);
    }


    LuaValue::LuaValue (const LuaUserDataTypeWrapper& ud)
    : eType(dataUserType)
    {
        if(ud.size>=SCRIPT_MAXSIZE_UD)
        {
            throw LuaUDError("User Data Size exceed max UserData Size");
        }
        this->udNode.size = ud.size;
        memset(this->udNode.szData,0,sizeof(this->udNode.szData));
        memcpy(this->udNode.szData,(char*)ud.ptr,ud.size);
    }

    //be careful...
    LuaValue::LuaValue (const LuaValueList& v)
    : eType(dataNil)
    {
        if (v.size() >= 1)
        {
            *this = v[0];
        }
        else
        {
            //*this = Nil;
            this->eType = dataNil;
        }
    }


    LuaValue::LuaValue (const LuaValue& other)
    : eType(other.eType)
    {
        switch (eType)
        {
            case dataBoolean:
                this->booleanNode.bValue = other.booleanNode.bValue;
            break;

            case dataNumber:
                this->numNode.nValue = other.numNode.nValue;
            break;

            case dataString:
                memcpy(this->strNode.strvar,other.strNode.strvar,SCRIPT_MAXSIZE_STRING);
            break;

            default:
            break;
        }
    }

    // - LuaValue::typeName -----------------------------------------------------
    std::string LuaValue::typeName() const
    {
        switch (eType)
        {
            case dataNil:
            return "nil";

            case dataBoolean:
            return "boolean";

            case dataNumber:
            return "number";

            case dataString:
            return "string";

            case dataUserType:
            return "userdata";

            default: // can't happen
            assert (false
            && "Invalid type found in a call to 'LuaValue::typeName()'.");
            return ""; 
        }
    }

    // - LuaValue::asNumber() ---------------------------------------------------
    lua_Number LuaValue::asNumber() const
    {
        if (eType == dataNumber)
        {
            return *reinterpret_cast<const lua_Number*>(&(this->numNode.nValue));
        }
        else
        {
            throw TypeMismatchError ("number", typeName());
        }
    }

    // - LuaValue::asInteger() --------------------------------------------------
    int LuaValue::asInteger() const
    {
        if (eType == dataNumber)
        {
            return static_cast<int>(this->numNode.nValue);
        }
        else
        {
            throw TypeMismatchError ("number", typeName());
        }
    }

    // - LuaValue::asInteger64() --------------------------------------------------
    long long LuaValue::asInteger64() const
    {
        if (eType == dataNumber)
        {
            return static_cast<long long>(this->numNode.nValue);
        }
        else
        {
            throw TypeMismatchError ("number", typeName());
        }
    }

    // - LuaValue::asString -----------------------------------------------------
    std::string LuaValue::asString() const
    {
        if (eType == dataString)
        {
            return string(this->strNode.strvar);
        }
        else
        {
            throw TypeMismatchError ("string", typeName());
        }
    }

    // - LuaValue::asBoolean ----------------------------------------------------
    bool LuaValue::asBoolean() const
    {
        if (eType == dataBoolean)
        {
            return this->booleanNode.bValue;
        }
        else
        {
            throw TypeMismatchError ("boolean", typeName());
        }
    }

    LuaUserDataTypeWrapper LuaValue::asUserData() const
    {
        if (eType == dataUserType)
        {
            LuaUserDataTypeWrapper ud;
            ud.size = this->udNode.size;
            ud.ptr = const_cast<char*>(this->udNode.szData);
            return ud;
        }
        else
        {
            throw TypeMismatchError ("userdata", typeName());
        }
    }

    // - LuaValue::operator< ----------------------------------------------------
    bool LuaValue::operator< (const LuaValue& rhs) const
    {
        std::string lhsTypeName = typeName();
        std::string rhsTypeName = rhs.typeName();

        if (lhsTypeName < rhsTypeName)
        {
            return true;
        }
        else if (lhsTypeName > rhsTypeName)
        {
            return false;
        }
        else // lhsTypeName == rhsTypeName,�������
        {
            switch (eType)
            {
                case dataNil:
                    return false;

                case dataBoolean:
                    return asBoolean() < rhs.asBoolean();

                case dataNumber:
                    return asNumber() < rhs.asNumber();

                case dataString:
                    return asString() < rhs.asString();

                case dataUserType:
                    return asUserData().size < rhs.asUserData().size;

                default: // can't happen
                    assert (false && "Unsupported type found at a call to 'LuaValue::operator<()'");
                    return false; 
            }
        }
    }

    // - LuaValue::operator> ----------------------------------------------------
    bool LuaValue::operator> (const LuaValue& rhs) const
    {
        std::string lhsTypeName = typeName();
        std::string rhsTypeName = rhs.typeName();

        if (lhsTypeName > rhsTypeName)
        {
            return true;
        }
        else if (lhsTypeName < rhsTypeName)
        {
            return false;
        }
        else // lhsTypeName == rhsTypeName,�������
        {
            switch (eType)
            {
                case dataNil:
                    return false;

                case dataBoolean:
                    return asBoolean() > rhs.asBoolean();

                case dataNumber:
                    return asNumber() > rhs.asNumber();

                case dataString:
                    return asString() > rhs.asString();

                case dataUserType:
                    return asUserData().size > rhs.asUserData().size;

                default: // can't happen
                    assert (false && "Unsupported type found at a call to 'LuaValue::operator>()'");
                    return false; 
            }
        }
    }

    // - LuaValue::operator== ---------------------------------------------------
    bool LuaValue::operator== (const LuaValue& rhs) const
    {
        std::string lhsTypeName = typeName();
        std::string rhsTypeName = rhs.typeName();

        if (lhsTypeName != rhsTypeName)
        {
            return false;
        }
        else // lhsTypeName == rhsTypeName,�������
        {
            switch (eType)
            {
                case dataNil:
                    return true;

                case dataBoolean:
                    return asBoolean() == rhs.asBoolean();

                case dataNumber:
                    return asNumber() == rhs.asNumber();

                case dataString:
                    return asString() == rhs.asString();

                case dataUserType:
                    return (asUserData().size == rhs.asUserData().size && asUserData().ptr == rhs.asUserData().ptr);

                default: // can't happen
                    assert (false && "Unsupported type found at a call to 'LuaValue::operator==()'");
                    return false; 
            }
        }
    }

    LuaValueList NullList;
} // namespace Luavatar

