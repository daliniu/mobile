#!/bin/sh

ARGS=1
E_BADARGS=65

if [ $# -lt "$ARGS" ] 
then
   echo "Usage: ${0##*/} luafilename.lua"
   exit $E_BADARGS
   fi

JCEFILES="*.jce"
LUAFILE=$1

rm -f $LUAFILE 
touch $LUAFILE

for FILE in $JCEFILES
do
    lua jce2luaconst.lua $FILE > $LUAFILE


done


exit 0

