local f = assert(io.open(arg[1], "r"))
local t = f:read("*all")
f:close()

--���ע��
t = string.gsub(t, "/\**.-*/", "")
t = string.gsub(t, "//.-\n", "")

local outfile = "";

for modulename, contant in string.gmatch(t, "module%s+([%a%d]+)%s*(%b{})") do
	--print(modulename, contant)

	local modulepart = modulename .. "= \n{"
 
	for name, value in string.gmatch(contant, "const%s+%a+%s+(%a+)%s*=%s*([%d%a_\"]+);") do
		modulepart = modulepart .. "\n\t" .. name .. " = " .. value .. ","
	end

	 modulepart = modulepart .. "\n}\n"

	outfile = outfile .. "\n" .. modulepart

end

print(outfile) 
