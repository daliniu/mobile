--require "util.printr"
--local array = require "util.array"
--local print_r = print_r

function access_dc()
     local mRs
     --local mRs = aDc:get_mapReserve()
     --print("Before:" .. aDc:get_byVersion() .. " " ..  aDc:get_sName() .. " " .. aDc:get_iBirth() .. " " ..  mRs["d1"] .. " " .. mRs["d2"] .. " " .. mRs["d3"] .. " " .. mRs["d4"] .. " " .. mRs["d5"])
     aDc:get_byVersion()
     aDc:get_sName()
     aDc:get_iBirth()

     aDc:set_byVersion('1')
     aDc:set_sName("papapa")
     aDc:set_iBirth(34567678)
     aDc:set_mapReserve("d1","xxoo1")
     aDc:set_mapReserve("d2","xxoo2")
     aDc:set_mapReserve("d3","xxoo3")
     aDc:set_mapReserve("d4","xxoo4")
     aDc:set_mapReserve("d5","xxoo5")

     aDc:get_mapReserve("d1")
     aDc:get_mapReserve("d2")
     aDc:get_mapReserve("d3")
     aDc:get_mapReserve("d4")
     aDc:get_mapReserve("d5")
     --mRs = aDc:get_mapReserve()
     --print("After:" .. aDc:get_byVersion() .. " " ..  aDc:get_sName() .. " " .. aDc:get_iBirth() .. " " ..  mRs["d1"] .. " "  .. mRs["d2"] .. " " .. mRs["d3"] .. " " .. mRs["d4"] .. " " .. mRs["d5"])
     
end
