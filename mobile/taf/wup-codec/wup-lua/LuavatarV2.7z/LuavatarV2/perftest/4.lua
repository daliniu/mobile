--require "util.printr"
--local array = require "util.array"
--local print_r = print_r

function access_psi()
     --print("Before:" .. aPsi:get_sName() .. " " ..  aPsi:get_sMasterName())
     aPsi:get_lPetid()
     aPsi:get_sName()
     aPsi:get_sMasterName()
     aPsi:get_iReserve1()
     aPsi:get_iReserve2()
     
     aPsi:set_lPetid(2200000000)
     aPsi:set_sName("PSI-II")
     aPsi:set_sMasterName("MA-II")
     aPsi:set_iReserve1(1)
     aPsi:set_iReserve2(2)
     --print("After:" .. aPsi:get_sName() .. " " ..  aPsi:get_sMasterName())
end
