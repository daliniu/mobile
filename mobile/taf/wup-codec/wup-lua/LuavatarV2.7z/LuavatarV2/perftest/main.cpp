#include <iostream>
#include "servant/Application.h"
#include "util/tc_option.h"
#include "util/tc_thread_pool.h"
#include "util/tc_common.h"
#include "luaregistry.h"
#include "SgameGlobal.h"
#include "MPetDataDef.h"
#include "count_time.hpp"
#include "LuaVmPool.h"
#include "LuaVm.h"

using namespace std;
using namespace taf;
using namespace Luavatar;
//using namespace MPet;

void showHelp()
{
    cout<<"Usage:"<<endl;
    cout<<"luavatartest --case=string"<<endl;
    exit(0);
}

TC_ThreadPool tpool;

/**
 * �߳�˽������
 */
class MyThreadData : public TC_ThreadPool::ThreadData
{
public:
    virtual ~MyThreadData()
    {
        cout << pthread_self() <<" stoped."<< endl;
    }

public:
    pthread_t 	_idata;
	LuaState  	_ls;
	TCountTime  _ct;
};

/**
 * �̳߳�ʼ��
 */
void threadInitialize()
{
    MyThreadData *p = TC_ThreadPool::ThreadData::makeThreadData<MyThreadData>();
    p->_idata = pthread_self();
	p->_ls["thread_tag"] = p->_idata;
    // �����ṹ
    REGISTER_STRUCT(MPet::stPetSimpleInfo,p->_ls);
    REGISTER_STRUCT(MPet::DCPetInfo,p->_ls);

    TC_ThreadPool::setThreadData(p);

    cout << p->_idata << "|" << p->_ls["thread_tag"].value().asInteger64() << endl;
}

/**
 * �����̳߳�
 */
template<class ParentFunctor>
void RunTest(int iThreadNum,const TC_FunctorWrapper<ParentFunctor> &tf)
{
    // �߳�
    tpool.init(iThreadNum);

    TC_Functor<void> init(threadInitialize);
    TC_Functor<void>::wrapper_type iwt(init);
    //�����߳�
    tpool.start(iwt);

    cout << "Start Thread Func..." << endl;
    
	for(unsigned i=0;i<tpool.getThreadNum();i++)
	{
		tpool.exec(tf);
	}

    //�ȴ��߳̽���
    bool b = tpool.waitForAllDone(1000);
    cout << "waitForAllDone..." << b << ":" << tpool.getJobNum() << endl;
    //�߳̽���ʱ,���Զ��ͷ�˽������
    tpool.stop();
}

/**
 * �����̳߳�
 */
template<class ParentFunctor>
void RunTestWithPool(int iThreadNum,const TC_FunctorWrapper<ParentFunctor> &tf)
{
    // �߳�
    tpool.init(iThreadNum);

    //�����߳�
    tpool.start();

    cout << "Start Thread Func..." << endl;
    
	for(unsigned i=0;i<tpool.getThreadNum();i++)
	{
		tpool.exec(tf);
	}

    //�ȴ��߳̽���
    bool b = tpool.waitForAllDone(1000);
    cout << "waitForAllDone..." << b << ":" << tpool.getJobNum() << endl;
    //�߳̽���ʱ,���Զ��ͷ�˽������
    tpool.stop();
}
/////////////////////////////////////////////////////////////////////////////////////////////////
//��������
/**
 * Case1�����Զ��߳̽ű�����
 * @param sFile
 * @param iNum
 */
void TestExeLuaFile(const string &sFile,int iNum)
{
    MyThreadData *p = (MyThreadData*)TC_ThreadPool::getThreadData();
    assert(pthread_self() == p->_idata);
	
	p->_ct.vBegin();
	for(int i = 0;i<iNum;i++)
	{
		//LOG->debug()<<p->_idata<<"|"<<p->_ls["thread_tag"].value().asInteger64()<<"|doFile "<<sFile<<" Begin("<<i<<")"<<endl;
		p->_ls.doFile(sFile);
		//LOG->debug()<<p->_idata<<"|"<<p->_ls["thread_tag"].value().asInteger64()<<"|doFile "<<sFile<<" End("<<i<<")"<<endl;
	}
	p->_ct.vEnd();
	LOG->debug()<<p->_idata<<"|TestExeLuaFile("<<sFile<<")"<<"|"<<iNum<<"|"<<p->_ct.iCountUsec()<<endl;
}

/**
 * Case2�����Զ��߳̽ṹ����
 *  ���Է�����ѭ��ִ��һ���ṹ��C++��Lua���໥����
 * @param sFile
 * @param iNum
 */
void TestStructInLua(const string &sFile,int iNum)
{
    MyThreadData *p = (MyThreadData*)TC_ThreadPool::getThreadData();
    assert(pthread_self() == p->_idata);
	
	p->_ct.vBegin();
	p->_ls.doFile(sFile);
    MPet::DCPetInfo dc;
    REGISTER_OBJ(p->_ls["aDc"],MPet::DCPetInfo,&dc);
    LuaValueList params,values;
    params.clear();
    values.clear();
	for(int i = 0;i<iNum;i++)
	{
		dc.byVersion    = 1;
	    dc.sName        = "QiQi";
	    dc.bySpecies    = 1;
	    dc.bySex        = 1;
	    dc.byTrustee    = 1;
	    dc.iBirth       = 123456;
	    dc.byAvatar     = 1;
	    dc.iPetLevel    = 20;
	    dc.sMasterName  = "PiPi";
	    dc.iMarryTime   = 256895;
	    dc.iMateID      = 1000000;
	    dc.iGrowth      = 2345;
	    dc.iHot         = 345;
	    dc.iIq          = 456;
	    dc.iPower       = 321;
	    dc.iCharm       = 789;
	    dc.iStrong      = 345;
	    dc.iUpStrong    = 123;
	    dc.iStarvation  = 345;
	    dc.iUpStarvation= 5678;
	    dc.iCleaness    = 4566;
	    dc.iUpCleaness  = 4444;
	    dc.iHealthness  = 5555;
	    dc.iFeeling     = 6666;
	    dc.iTimeLong    = 7777;
	    dc.iLastCalcTime= 8888;
	    dc.iOnlineTime  = 9999;
	    dc.iOfflineTime = 1111; 
	    dc.byUserFlag   = 1;
	    dc.byReserve1   = 0;
	    dc.byReserve2   = 1;
	    dc.byReserve3   = 0;
	    dc.iReserve1    = 111;
	    dc.iReserve2    = 222;
	    dc.iReserve3    = 333;
	    dc.byVipPayType    = 0;
	    dc.iVipOpenTime    = 999;
	    dc.iVipExpireTime  = 888;
	    dc.byReserve4      = 1;
	    dc.byReserve5      = 1;
	    dc.byReserve6      = 1;
	    dc.byCareerId      = 1;
	    dc.byReserve8      = 1;
	    dc.byReserve9      = 1;
	    dc.byReserve10     = 1;
	    dc.byReserve11     = 1;
	    dc.byReserve12     = 1;
	    dc.byReserve13     = 1;
	    dc.byReserve14     = 1;
	    dc.byReserve15     = 1;
	    dc.byReserve16     = 1;
	    dc.byReserve17     = 1;
	    dc.byReserve18     = 1;
	    dc.byReserve19     = 1;
	    dc.byReserve20     = 1;
	    dc.iReserve4       = 444;
	    dc.iReserve5       = 555;
	    dc.iReserve6       = 666;
	    dc.iReserve7       = 777;
	    dc.iReserve8       = 8888;
	    dc.iReserve9       = 9999;
	    dc.iReserve10      = 777;
	    dc.iReserve11      = 4444;
	    dc.iReserve12      = 3333;
	    dc.iReserve13      = 6666;
	    dc.iReserve14      = 2222;
	    dc.iReserve15      = 88885;
	    dc.mapReserve["d1"]="d1";
		dc.mapReserve["d2"]="d2";
		dc.mapReserve["d3"]="d3";
		dc.mapReserve["d4"]="d4";
		dc.mapReserve["d5"]="d5";
		
		//LOG->debug()<<p->_idata<<"|"<<p->_ls["thread_tag"].value().asInteger64()<<"|Before"<<logJce(dc)<<endl;
        p->_ls["access_dc"]();
		//LOG->debug()<<p->_idata<<"|"<<p->_ls["thread_tag"].value().asInteger64()<<"|After"<<logJce(dc)<<endl;
	}
	p->_ct.vEnd();
	LOG->debug()<<p->_idata<<"|TestStructInLua("<<sFile<<")"<<"|"<<sizeof(MPet::DCPetInfo)<<"|"<<iNum<<"|"<<p->_ct.iCountUsec()<<endl;
}

/**
 * Case2�����Զ��߳�С�ṹ����
 *  ���Է�����ѭ��ִ��һ���ṹ��C++��Lua���໥����
 * @param sFile
 * @param iNum
 */
void TestStructInLuaSmall(const string &sFile,int iNum)
{
    MyThreadData *p = (MyThreadData*)TC_ThreadPool::getThreadData();
    assert(pthread_self() == p->_idata);
	
	p->_ct.vBegin();
	p->_ls.doFile(sFile);
    MPet::stPetSimpleInfo psi;
	psi.lPetid = 1000000000;
	psi.sName = "PSI-I";
	psi.sMasterName = "MA-I";
	psi.iReserve1 = 0;
	psi.iReserve2 = 0;
    REGISTER_OBJ(p->_ls["aPsi"],MPet::stPetSimpleInfo,&psi);

    LuaValueList params,values;
    params.clear();
    values.clear();
	for(int i = 0;i<iNum;i++)
	{
		//LOG->debug()<<p->_idata<<"|"<<p->_ls["thread_tag"].value().asInteger64()<<"|Before"<<logJce(dc)<<endl;
         p->_ls["access_psi"]();
	     psi.lPetid = 1000000000;
         psi.sMasterName = "MA-I";
         psi.sName = "PSI-I";
	     psi.iReserve1 = 0;
	     psi.iReserve2 = 0;

		//LOG->debug()<<p->_idata<<"|"<<p->_ls["thread_tag"].value().asInteger64()<<"|After"<<logJce(psi)<<endl;
	}
	p->_ct.vEnd();
	LOG->debug()<<p->_idata<<"|TestStructInLuaSmall("<<sFile<<")"<<"|"<<sizeof(MPet::stPetSimpleInfo)<<"|"<<iNum<<"|"<<p->_ct.iCountUsec()<<endl;
}


/**
 * Case1������״̬��
 * @param sFile
 * @param iNum
 */
void TestFsm(const string &sFile,int iNum)
{
    MyThreadData *p = (MyThreadData*)TC_ThreadPool::getThreadData();
    assert(pthread_self() == p->_idata);
	
	p->_ct.vBegin();
	p->_ls.doFile(sFile);
	vector<string> inputList;
	inputList.push_back("rock");
	inputList.push_back("paper");
	inputList.push_back("scissors");
	
    LuaValueList params,lv;
    lv.clear();

	for(int i = 0;i<iNum;i++)
	{
        params.clear();
        params.push_back(LuaValue(inputList[rand()%3]));
		p->_ls["fsm_rps"]["ST_INIT"]["EV_START"]["action"](params,lv);
	}
	
	p->_ls["fsm_rps"]["ST_PLAYING"]["EV_STOP"]["action"](params,lv);
	//LOG->debug()<<p->_idata<<"|"<<p->_ls["thread_tag"].value().asInteger64()<<"|Result:"<<lv[0].asInteger()<<"|"<<lv[1].asInteger()<<"|"<<lv[2].asInteger()<<endl;
	LOG->debug()<<&(p->_ls)<<":Result:You:"<<lv[0].asInteger()<<"|Computer:"<<lv[1].asInteger()<<"|Draw:"<<lv[2].asInteger()<<endl;
	p->_ct.vEnd();
	LOG->debug()<<p->_idata<<"|TestFsm("<<sFile<<")"<<"|"<<iNum<<"|"<<p->_ct.iCountUsec()<<endl;
}

/**
 * Case1������LuaVmPool
 * @param sFile
 * @param iNum
 */
void TestVmPool(const string &sFile,int iNum)
{
    pool_object<LuaVm> aVm(LuaVmPool<LuaVm>::getInstance());
	
	aVm->getState().doFile(sFile);
	vector<string> inputList;
	inputList.push_back("rock");
	inputList.push_back("paper");
	inputList.push_back("scissors");
	
    LuaValueList params,lv;
    lv.clear();

    //sleep(1);
	for(int i = 0;i<iNum;i++)
	{
        params.clear();
        params.push_back(LuaValue(inputList[rand()%3]));
		aVm->getState()["fsm_rps"]["ST_INIT"]["EV_START"]["action"](params,lv);
	}
	
	aVm->getState()["fsm_rps"]["ST_PLAYING"]["EV_STOP"]["action"](params,lv);
	LOG->debug()<<aVm->getVmTag()<<":Result:You:"<<lv[0].asInteger()<<"|Computer:"<<lv[1].asInteger()<<"|Draw:"<<lv[2].asInteger()<<endl;
	LOG->debug()<<"|TestVmPool("<<sFile<<")"<<"|"<<iNum<<"|"<<endl;
}
int main(int argc, char *argv[])
{
    try
	{
        ///////////////////////////////////////////////////////////////////////////
        TC_Option op;
        op.decode(argc, argv);
		TC_Config conf;
		conf.parseFile("Luavatar.PerfTest.conf");
		
		TafRollLogger::getInstance()->setLogInfo("Luavatar", "LuavatarPerfTest", "./log", 104857600,5);
		TafRollLogger::getInstance()->sync(true);

        if(op.hasParam("case"))
        {
           string sCase = op.getValue("case");
           if(sCase == "f")
           {
			   int iThreadNum = TC_Common::strto<int>(conf.get("/Cases/TestFile<thread-num>"));
			   string sFile = conf.get("/Cases/TestFile<file-name>");
			   int iLoop = TC_Common::strto<int>(conf.get("/Cases/TestFile<loop-count>"));
			   TC_Functor<void, TL::TLMaker<const string&, int>::Result> cmd(TestExeLuaFile);
			   TC_Functor<void, TL::TLMaker<const string&, int>::Result>::wrapper_type fw(cmd, sFile, iLoop);
			   
               RunTest(iThreadNum,fw);
           }
		   else if(sCase == "s")
		   {
			   int iThreadNum = TC_Common::strto<int>(conf.get("/Cases/TestStack<thread-num>"));
			   string sFile = conf.get("/Cases/TestStack<file-name>");
			   int iLoop = TC_Common::strto<int>(conf.get("/Cases/TestStack<loop-count>"));
			   TC_Functor<void, TL::TLMaker<const string&, int>::Result> cmd(TestStructInLua);
			   TC_Functor<void, TL::TLMaker<const string&, int>::Result>::wrapper_type fw(cmd, sFile, iLoop);
			   
               RunTest(iThreadNum,fw);
		   }
		   else if(sCase == "ss")
		   {
			   int iThreadNum = TC_Common::strto<int>(conf.get("/Cases/TestStackSmall<thread-num>"));
			   string sFile = conf.get("/Cases/TestStackSmall<file-name>");
			   int iLoop = TC_Common::strto<int>(conf.get("/Cases/TestStackSmall<loop-count>"));
			   TC_Functor<void, TL::TLMaker<const string&, int>::Result> cmd(TestStructInLuaSmall);
			   TC_Functor<void, TL::TLMaker<const string&, int>::Result>::wrapper_type fw(cmd, sFile, iLoop);
			   
               RunTest(iThreadNum,fw);
		   }
		   else if(sCase == "m")
		   {
			   int iThreadNum = TC_Common::strto<int>(conf.get("/Cases/TestFsm<thread-num>"));
			   string sFile = conf.get("/Cases/TestFsm<file-name>");
			   int iLoop = TC_Common::strto<int>(conf.get("/Cases/TestFsm<loop-count>"));
			   TC_Functor<void, TL::TLMaker<const string&, int>::Result> cmd(TestFsm);
			   TC_Functor<void, TL::TLMaker<const string&, int>::Result>::wrapper_type fw(cmd, sFile, iLoop);
			   
               RunTest(iThreadNum,fw);
		   }
		   else if(sCase == "pool")
		   {
			   int iThreadNum = TC_Common::strto<int>(conf.get("/Cases/TestVmPool<thread-num>"));
			   string sFile = conf.get("/Cases/TestVmPool<file-name>");
			   int iLoop = TC_Common::strto<int>(conf.get("/Cases/TestVmPool<loop-count>"));
			   TC_Functor<void, TL::TLMaker<const string&, int>::Result> cmd(TestVmPool);
			   TC_Functor<void, TL::TLMaker<const string&, int>::Result>::wrapper_type fw(cmd, sFile, iLoop);
			   
               std::map<string,string> pool_conf;
               pool_conf["MaxSize"] = "10";
               pool_conf["MinSize"] = "4";
               LuaVmPool<LuaVm>::getInstance()->init(pool_conf);
               RunTestWithPool(iThreadNum,fw);
		   }
           else
           {
               showHelp();
           }
        }
        else
        {
            showHelp();
        }
        
	}
	catch(exception &ex)
	{
        cout << ex.what() << endl;
        exit(0);
	}

	return 0;
}

