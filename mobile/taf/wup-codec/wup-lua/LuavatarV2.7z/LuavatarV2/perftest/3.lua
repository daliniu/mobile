lockup = {}

lockup["rock"]     = {rock = "draw", paper = "lose", scissors = "win"}
lockup["paper"]    = {rock = "win",  paper = "draw", scissors = "lose"}
lockup["scissors"] = {rock = "lose", paper = "win",  scissors = "draw"}
math.randomseed(os.time())

computer_count = 0
you_count = 0
draw_count = 0

function play_game(choice)
	local names = {"rock", "paper", "scissors"}
    local computer = names [math.random(3)]
	--print("Computer:" .. computer)
    --print("You:" .. choice)
	local result = lockup[choice][computer] 

	if (result == "win") then
		you_count = you_count + 1 
		--print("You win the Round." .. you_count)
	elseif (result == "lose") then
		computer_count = computer_count + 1
		--print("Computer Wins the Round." .. computer_count)
	elseif (result == "draw") then
		draw_count = draw_count + 1 
		--print("Draw." .. draw_count)
	else
		--print("Invalid input.")
	end
end

function stop_game()
	--print("You winned:" .. you_count)
	--print("Computer winned:" .. computer_count)
	--print("Drawed:" .. draw_count)
	
	return you_count,computer_count,draw_count
end

function FSM(t)
  local a = {}
  for _,v in ipairs(t) do
    local old, event, new, action = v[1], v[2], v[3], v[4]
    if a[old] == nil then a[old] = {} end
    a[old][event] = {new = new, action = action}
  end
  return a
end

--old,event,new,action
fsm_rps = FSM{
  {"ST_INIT", "EV_START", "ST_PLAYING", play_game},
  {"ST_PLAYING", "EV_STOP", "ST_INIT", stop_game},
}
