#ifndef _LUA_INCLUDE_H_
#define _LUA_INCLUDE_H_

#ifdef __cplusplus
extern "C" {
#endif 
#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"
#ifdef __cplusplus
}
#endif

#endif
