#ifndef _LUA_BASE_VM_H_
#define _LUA_BASE_VM_H_

#include "LuaVmPool.h"

extern int g_VmTag;

namespace Luavatar
{
    
class LuaBaseVm
{
    public:
        LuaBaseVm(std::map<string,string> conf)
        {
            _tag = ++g_VmTag;
        }
        virtual ~LuaBaseVm()
        {
        }

    public:
        LuaState& getState()
        {
            return _ls;
        }

        virtual bool isValid(int iTimeStamp)
        {
            return ((getTimeStamp() == iTimeStamp) && (getState().getState() != NULL));
            //return true;
        }

        int getVmTag()
        {
            return _tag;
        }

        int getTimeStamp()
        {
            return _iTimeStamp;
        }

        void setTimeStamp(int iTimeStamp)
        {
            _iTimeStamp = iTimeStamp;

            return;
        }

        //��ɢ����������ֵ
        template<typename T>
        void pushParam(const string& sName,T val)
        {
            getState()["paramIn"][sName] = val;

            return;
        }

        void popResult(const string& sName,int& val)
        {
            val = getState()["resultOut"][sName].value().asInteger();

            return;
        }

        void popResult(const string& sName,string& val)
        {
            val = getState()["resultOut"][sName].value().asString();

            return;
        }

        void popResult(const string& sName,bool& val)
        {
            val = getState()["resultOut"][sName].value().asBoolean();

            return;
        }

        //�ṹ�������õ���
        template<typename T>
        void pushObjRef(const string& sName,T* obj)
        {
            REGISTER_OBJ(getState()[sName],T,obj);
        }

    protected:
        virtual int init(std::map<string,string> conf) = 0;
        
    private:
        LuaState _ls;
        
        int      _tag;
        int      _iTimeStamp;
};

}

#endif

