#ifndef _LUAVATAR_LUA_VALUE_H_
#define _LUAVATAR_LUA_VALUE_H_

#include "luainclude.h"
#include <map>
#include <stdexcept>
#include <string>
#include "luavatartypes.h"
#include "luaexception.h"

using namespace std;

namespace Luavatar
{
    /*! 
    * \brief LuaValue�Ƕ�Lua���������͵ķ�װ��֧�ֵ�����������:
    * ��������(��ӦC++�е���Ӧ����)����(��ӦC++�е�map)
    * �Լ�UserData(һ��raw memory)
    */
    class LuaValue
    {
        public:
        LuaValue();

        LuaValue (bool b);

        LuaValue (float n);

        LuaValue (double n);

        LuaValue (long double n);

        LuaValue (short n);

        LuaValue (unsigned short n);

        LuaValue (int n);

        LuaValue (unsigned int n);

        LuaValue (long n);

        LuaValue (unsigned long n);

        LuaValue (long long n);

        LuaValue (const std::string& s);

        LuaValue (const char* s);

        LuaValue (const LuaUserDataTypeWrapper& ud);

        LuaValue (const LuaValueList& v);

        LuaValue (const LuaValue& other);

        ~LuaValue() {}

        //��ֵ��������
        LuaValue& operator= (bool rhs)
        {
            eType = dataBoolean;
            this->booleanNode.bValue = rhs;
            return *this;
        }

        LuaValue& operator= (float rhs)
        {
            eType = dataNumber;
            this->numNode.nValue = rhs;
            return *this;
        }

        LuaValue& operator= (double rhs)
        {
            eType = dataNumber;
            this->numNode.nValue = rhs;
            return *this;
        }

        LuaValue& operator= (long double rhs)
        {
            eType = dataNumber;
            this->numNode.nValue = rhs;
            return *this;
        }

        LuaValue& operator= (short rhs)
        {
            eType = dataNumber;
            this->numNode.nValue = rhs;
            return *this;
        }

        LuaValue& operator= (unsigned short rhs)
        {
            eType = dataNumber;
            this->numNode.nValue = rhs;
            return *this;
        }

        LuaValue& operator= (int rhs)
        {
            eType = dataNumber;
            this->numNode.nValue = rhs;
            return *this;
        }

        LuaValue& operator= (unsigned int rhs)
        {
            eType = dataNumber;
            this->numNode.nValue = rhs;
            return *this;
        }

        LuaValue& operator= (long rhs)
        {
            eType = dataNumber;
            this->numNode.nValue = rhs;
            return *this;
        }

        LuaValue& operator= (unsigned long rhs)
        {
            eType = dataNumber;
            this->numNode.nValue = rhs;
            return *this;
        }

        LuaValue& operator= (long long rhs)
        {
            eType = dataNumber;
            this->numNode.nValue = rhs;
            return *this;
        }

        LuaValue& operator= (const std::string& rhs)
        {
            eType = dataString;
            if(rhs.length()>=SCRIPT_MAXSIZE_STRING)
            {
                throw LuaStringError("String length exceed max string Size");
            }

            memset(this->strNode.strvar,0,sizeof(this->strNode.strvar));
            memcpy(this->strNode.strvar,rhs.c_str(),rhs.length());
            return *this;
        }

        LuaValue& operator= (const char* rhs)
        {
            if(strlen(rhs)>=SCRIPT_MAXSIZE_STRING)
            {
                throw LuaStringError("String length exceed max string Size");
            }

            memset(this->strNode.strvar,0,sizeof(this->strNode.strvar));
            strncpy(this->strNode.strvar,rhs,SCRIPT_MAXSIZE_STRING);
            return *this;
        }

        LuaValue& operator= (const LuaUserDataTypeWrapper& rhs)
        {
            eType = dataUserType;
            if(rhs.size>=SCRIPT_MAXSIZE_UD)
            {
                throw LuaUDError("User Data Size exceed max UserData Size");
            }
            this->udNode.size = rhs.size;
            memset(this->udNode.szData,0,sizeof(this->udNode.szData));
            memcpy(this->udNode.szData,(char*)rhs.ptr,rhs.size);
            return *this;
        }
        
        LuaValue& operator= (const LuaValueList& rhs)
        {
          if (rhs.size() >= 1)
          {
             *this = rhs[0];
          }
          else
          {
             eType = dataNil;
          }

          return *this;
        }

        char type() const { return eType; }

        std::string typeName() const;

        lua_Number asNumber() const;

        int asInteger() const;

        long long asInteger64() const;

        std::string asString() const;

        bool asBoolean() const;
        
        LuaUserDataTypeWrapper asUserData() const;

        struct CppObject
        {
            void* ptr;
        }__attribute__((packed));
        
        template<class T>
        T asObjectPtr() const
        {
            return static_cast<T>(
                static_cast<CppObject*>(asUserData().ptr)->ptr);
        }

        bool operator< (const LuaValue& rhs) const;

        bool operator> (const LuaValue& rhs) const;

        bool operator== (const LuaValue& rhs) const;

        bool operator!= (const LuaValue& rhs) const
        { return !(*this == rhs); }

        public:
        char eType;
        union
        {
            BooleanData booleanNode;    /* bool     */
            NumData     numNode;        /* number */
            StrData     strNode;        /* string   */
            UserData    udNode;         /* user data */
            //���ܿ�������table�ĵ���������Ե�����Ա��
            //TabData     tabNode;
        };
        
    };

    extern LuaValueList NullList;
   
} // namespace Luavatar


#endif // _LUAVATAR_LUA_VALUE_H_

