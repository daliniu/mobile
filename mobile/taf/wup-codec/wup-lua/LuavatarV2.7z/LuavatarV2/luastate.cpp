#include <cassert>
#include <cstring>
#include <typeinfo>
#include "luastate.h"
#include "luautil.h"

namespace Luavatar
{
    // - LuaState::LuaState -----------------------------------------------------
    LuaState::LuaState (bool loadStdLib)
      : state_(0), ownsState_(true)
    {
        state_ = luaL_newstate();
        if (state_ == 0)
        {
            throw LuaError ("Error opening Lua state.");
        }

        if (loadStdLib)
        {
            luaL_openlibs (state_);
        }
    }

    LuaState::LuaState (lua_State* state, bool loadStdLib)
      : state_(state), ownsState_(false)
    {
        if (state_ == 0)
        {
            throw LuaError ("Constructor of 'LuaState' got a NULL pointer.");
        }

        if (loadStdLib)
        {
            luaL_openlibs (state_);
        }
    }

    // - LuaState::~LuaState ----------------------------------------------------
    LuaState::~LuaState()
    {
        if (ownsState_ && state_ != 0)
        {
            lua_close (state_);
        }
    }

    // - LuaState::doStringOrFile -----------------------------------------------
    LuaValueList LuaState::execTrunk (bool isString, const std::string& str)
    {
        const int stack_size = lua_gettop (state_);
        if (isString)
        {
            LuaUtil::ThrowOnLuaError (state_, luaL_loadbuffer (state_, str.c_str(),                                    str.length(), "line"));
        }
        else
        {
            LuaUtil::ThrowOnLuaError (state_, luaL_loadfile (state_, str.c_str()));
        }

        LuaUtil::ThrowOnLuaError (state_, lua_pcall (state_, 0, LUA_MULTRET, 0));

        const int num_results = lua_gettop (state_) - stack_size;

        LuaValueList results;
        LuaValue     tblValue;
        for (int i = num_results; i > 0; --i)
        {
            LuaUtil::ToLuaValue(state_,-i,tblValue);
            results.push_back (tblValue);
        }

        lua_pop (state_, num_results);

        return results;
    }

    // - LuaState::call ---------------------------------------------------------
    int LuaState::call (const string& func,
                        const LuaValueList& params,
                        LuaValueList& values,
                        const std::string& chunkName)
    {
        //lua_pushlstring (state_, func.c_str(), func.length());
        //lua_gettable(state_, LUA_GLOBALSINDEX);
        lua_getglobal(state_, func.c_str());  
        return LuaUtil::CallFunctionOnTop (state_, params, values);
    }

    int LuaState::call (const string& func,
                        const std::string& chunkName)
    {
        //lua_pushlstring (state_, func.c_str(), func.length());
        //lua_gettable(state_, LUA_GLOBALSINDEX);
        lua_getglobal(state_, func.c_str());  
        return LuaUtil::CallFunctionOnTop (state_, NullList, NullList);
    }

    int LuaState::call (const string& func,
                        LuaValueList& values,
                        const std::string& chunkName)
    {
        //lua_pushlstring (state_, func.c_str(), func.length());
        //lua_gettable(state_, LUA_GLOBALSINDEX);
        lua_getglobal(state_, func.c_str());  
        return LuaUtil::CallFunctionOnTop (state_, NullList, values);
    }

    int LuaState::call (const string& func,
                        const LuaValueList& params,
                        const std::string& chunkName)
    {
        //lua_pushlstring (state_, func.c_str(), func.length());
        //lua_gettable(state_, LUA_GLOBALSINDEX);
        lua_getglobal(state_, func.c_str());  
        return LuaUtil::CallFunctionOnTop (state_, params, NullList);
    }

    // - LuaState::operator[] ---------------------------------------------------
    LuaVariable LuaState::operator[] (const std::string& variable)
    {
        assert(variable != "_G" && "Can't access '_G'; ");
        return LuaVariable (state_, variable);
    }

} // namespace Luavatar

