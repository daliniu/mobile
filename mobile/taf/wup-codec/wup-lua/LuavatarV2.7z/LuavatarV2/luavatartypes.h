#ifndef _LUAVATAR_TYPES_H_
#define _LUAVATAR_TYPES_H_

#include <map>
#include <vector>


namespace Luavatar
{
    class LuaValue;
    
    /** <tt>LuaValue</tt>�б�. ������Ӧ���������洢lua function�ķ���ֵ����.
    */
    typedef std::vector<LuaValue> LuaValueList;
    
    /**
     * ֧�ֵ�datatype
     */
    typedef enum 
    { 
        dataNil = 0,
        dataBoolean,
        dataNumber,
        dataString,
        dataUserType,
        maxSupportDataTypeCnt
    } eDataType;

    
    typedef struct
    {
        size_t size;
        void*  ptr;
        
    } LuaUserDataTypeWrapper;

    typedef struct
    {
        bool bValue;
        
    } BooleanData;

    typedef struct 
    {
        double nValue;

    } NumData;
    
    typedef struct 
    {
        int nValue;

    } IntData;

    typedef struct 
    {
        double fValue;

    } FltData;

    #ifndef SCRIPT_MAXSIZE_STRING
    #define SCRIPT_MAXSIZE_STRING 512
    #endif
    typedef struct 
    {
        char  strvar[SCRIPT_MAXSIZE_STRING];
        
    } StrData;

    #ifndef SCRIPT_MAXSIZE_UD
    #define SCRIPT_MAXSIZE_UD 512
    #endif
    typedef struct
    {
        size_t size;
        char   szData[SCRIPT_MAXSIZE_UD];
    } UserData;
    
} // namespace Luavatar

#endif // _LUAVATAR_TYPES_H_

