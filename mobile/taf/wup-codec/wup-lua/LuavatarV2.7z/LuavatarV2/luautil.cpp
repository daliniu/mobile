#include <cstring>
#include <sstream>
#include <assert.h>
#include "luautil.h"
#include "luaexception.h"

namespace Luavatar
{    
    // - CallFunctionOnTop ---------------------------------------------------
    int LuaUtil::CallFunctionOnTop (lua_State* ls, const LuaValueList& params, LuaValueList& values)
    {
        int base = lua_gettop (ls);

        if (lua_type (ls, -1) != LUA_TFUNCTION)
        {
            throw TypeMismatchError ("function", luaL_typename (ls, -1));
        }

        typedef LuaValueList::const_iterator iter_t;
        for (iter_t p = params.begin(); p != params.end(); ++p)
        {
            PushLuaValue (ls, *p);
        } 

        ThrowOnLuaError (ls, lua_pcall (ls, params.size(), LUA_MULTRET, 0));

        int numResults = lua_gettop (ls) - base + 1;
        values.clear();
        LuaValue   tblValue;
        for (int i = numResults; i > 0; --i)
        {
            ToLuaValue(ls, -i, tblValue);
            values.push_back (tblValue);
        }

        lua_pop (ls, numResults);

        return numResults;
    }



    // - ThrowOnLuaError -----------------------------------------------------
    void LuaUtil::ThrowOnLuaError (lua_State* ls, int statusCode)
    {
        if (statusCode != 0)
        {
            std::string errorMessage;
            if (lua_isstring (ls, -1))
            {
               errorMessage = lua_tostring (ls, -1);
               lua_pop (ls, 1);
            }
            else
            {
               errorMessage = "Sorry, there is no additional information about this error.";
            }

            switch (statusCode)
            {
               case LUA_ERRRUN:
                  throw LuaRunTimeError (errorMessage.c_str());
               case LUA_ERRFILE:
                  throw LuaFileError (errorMessage.c_str());
               case LUA_ERRSYNTAX:
                  throw LuaSyntaxError (errorMessage.c_str());
               case LUA_ERRMEM:
                  throw LuaMemoryError (errorMessage.c_str());
               case LUA_ERRERR:
                  throw LuaErrorError (errorMessage.c_str());
               default:
                  throw LuaError ("Unknown Lua return code passed "
                                  "to 'Luavatar::ThrowOnLuaError()'.");
            }
        }
    }

    // - ReportErrorFromCFunction --------------------------------------------
    void LuaUtil::ReportErrorFromCFunction (lua_State* ls, const::std::string& what)
    {
        lua_Debug ar;
        int ret = lua_getstack (ls, 0, &ar);

        assert (ret != 0 && "'lua_getstack()' wasn't supposed to return '0' "
             "here. Possible error cause: 'ReportErrorFromCFunction()' "
             "wasn't called from a Lua function implemented in C.");

        ret = lua_getinfo (ls, "n", &ar);

        assert (ret != 0 && "'lua_getinfo()' wasn't supposed to return '1' "
             "here. *Nothing* could go wrong at this point! Oh, well...");

        const std::string msg = std::string("Error found when calling '")
        + ar.name + "': " + what;

        lua_pushstring (ls, msg.c_str());
        lua_error (ls);
    }
    
    // - ToLuaValue -------------------------------------------------------------
    void LuaUtil::ToLuaValue (lua_State* state, int index, LuaValue& value)
    {
      switch (lua_type (state, index))
      {
         case LUA_TNIL:
            value.eType = dataNil;
            return;

         case LUA_TNUMBER:
           value = lua_tonumber (state, index);
           return;

         case LUA_TBOOLEAN:
            value = (lua_toboolean (state, index) != 0);
            return;

         case LUA_TSTRING:
         {
            size_t size = lua_objlen(state, index);
            if(size > SCRIPT_MAXSIZE_STRING)
            {
                throw LuaStringError("String length exceed max supported string size");
            }

            value.eType = dataString;
            memset(value.strNode.strvar,0,sizeof(value.strNode.strvar));
            memcpy(value.strNode.strvar,lua_tostring(state, index),size);
            return;
         }

         case LUA_TUSERDATA:
         {
            void* addr = lua_touserdata (state, index);
            size_t size = lua_objlen (state, index);
            if(size > SCRIPT_MAXSIZE_UD)
            {
                throw LuaUDError("UserData size exceed max supported UserData size");
            }

            value.eType = dataUserType;
            value.udNode.size = size;
            memset (value.udNode.szData,0,sizeof(value.udNode.szData));
            memcpy (value.udNode.szData, addr, size);
            return;
         }

         default:
         {
            std::ostringstream os;
        	os  << "Unsupported type found in call to 'ToLuaValue()': "
                << lua_type (state, index)
        		<< " (typename: \'"
        		<< luaL_typename (state, index)
        		<< "')";
            throw LuaTypeError(os.str().c_str());
         }
      }
    }

    // - PushLuaValue -----------------------------------------------------------
    void LuaUtil::PushLuaValue (lua_State* state, const LuaValue& value)
    {
      switch (value.eType)
      {
         case dataNil:
            lua_pushnil (state);
            break;

         case dataNumber:
            lua_pushnumber (state, value.numNode.nValue);
            break;
         
         case dataString:
         {
            const std::string& tmp = value.asString();
            lua_pushlstring (state, tmp.c_str(), tmp.length());
            break;
         }

         case dataBoolean:
            lua_pushboolean (state, value.booleanNode.bValue);
            break;

         case dataUserType:
         {
            size_t size = value.udNode.size;
            void* addr = lua_newuserdata (state, size);
            memcpy (addr, value.udNode.szData, size);
            /*if(meta != NilMeta)
            {
                PushLuaValue(state,meta);
                lua_setmetatable (state, -2);
            }*/

            break;
         }

         default:
         {
            std::ostringstream os;
        	os  << "Unsupported type found in call to 'PushLuaValue()': "
                << value.type()
        		<< " (typename: \'"
        		<< value.typeName()
        		<< "')";
            throw LuaTypeError(os.str().c_str());
         }
      }
    }

} // namespace Luavatar

